let i = 0;
let len;
let cd;

    const xhttp = new XMLHttpRequest();

xhttp.onload = function() {


    
  const xmlDoc = xhttp.responseXML;
  cd = xmlDoc.getElementsByTagName("CD");
  len = cd.length;
  displayCD(i);
}


xhttp.open("GET", "cd_catalog.xml");
xhttp.send();




function displayCD(i) {
  document.getElementById("artist").innerHTML = "Artist:" +
  
  cd[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue ;
  
  document.getElementById("title").innerHTML = "Title:" +

  cd[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue ;


  document.getElementById("year").innerHTML = "Year:" +
  
  cd[i].getElementsByTagName("YEAR")[0].childNodes[0].nodeValue;
}


// i value is zero (0) ; if len-1 = cd.length -1 means cd[0]-1;cd[1]-1;cd[2]-1
// i < len -1 = 1st time =>>  0 < cd.lenght - 1  = 0 < cd[i] -1 
//1st time  = 0 < cd[0]-1;
// 2nd time = 1 < cd[1] - 1;
// 3rd time = 2 < cd[2] - 2;
// condtion is true(i < len-1)  ==   i++ is apply  so on click displayCD(1),displayCD(2),displayCD(3)....

function nextFunc() {
  if (i < len-1) {
    i++;
    displayCD(i);
  }
}




// when i value greater than 0 : 1 > 0 , 2 > 0 , 3 > 0 ;
// on click i value is decrease;


function previousFunc() {
  if (i > 0) {
    i--;
    displayCD(i);
  }
}
